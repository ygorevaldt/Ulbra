export interface IFactory {
    execute(): any
}