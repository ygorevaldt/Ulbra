public interface Trainable {
    void performTrick();
}
