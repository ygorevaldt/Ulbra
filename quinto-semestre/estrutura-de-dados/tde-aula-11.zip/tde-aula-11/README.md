# TO-DO

## Inserção

[x] - Inserir no inicio
[x] - Inserir no fim
[x] - Inserir por posição

## Busca

[x] - Buscar por posição
[x] - Buscar posição


## Atualização

[x] - Atualizar

## Remoção

[x] - Remover do inicio
[x] - Remover do fim
[x] - Remover por valor
[x] - Remover por posição

## Outros métodos

[x] - Obter tamanho da lista
[x] - Verificar se a lista está vazia
[x] - Limpar lista
[x] - Mostrar lista (toString)
