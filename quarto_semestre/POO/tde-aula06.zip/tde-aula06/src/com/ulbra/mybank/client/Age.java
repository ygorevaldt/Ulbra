package com.ulbra.mybank.client;

public class Age {
}
