package com.ulbra.mybank.conta;

import com.ulbra.mybank.client.Client;

public class SavingsAccount extends Account {
    public SavingsAccount(Client client) {
        super(client);
    }
}
