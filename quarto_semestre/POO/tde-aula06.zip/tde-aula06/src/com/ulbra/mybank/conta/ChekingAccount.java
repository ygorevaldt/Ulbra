package com.ulbra.mybank.conta;

import com.ulbra.mybank.client.Client;

public class ChekingAccount extends Account {
    public ChekingAccount(Client client) {
        super(client);
    }
}
