export interface IPayment {
    pay(value: number): void
}