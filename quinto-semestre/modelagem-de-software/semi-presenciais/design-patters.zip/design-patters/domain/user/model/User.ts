export class User {
    constructor(
        readonly email: string,
        readonly password: string
    ) { }
}